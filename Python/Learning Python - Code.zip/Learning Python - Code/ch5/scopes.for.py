s = 0
for A in range(5):
    s += A
print(A)  # prints: 4
print(globals())
