word = 'Hello'

positions = {c: k for k, c in enumerate(word)}

print(positions)  # prints: {'l': 3, 'o': 4, 'e': 1, 'H': 0}
