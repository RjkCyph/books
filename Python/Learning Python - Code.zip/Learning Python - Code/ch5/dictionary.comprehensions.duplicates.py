word = 'Hello'

swaps = {c: c.swapcase() for c in word}

print(swaps)  # prints: {'o': 'O', 'l': 'L', 'e': 'E', 'H': 'h'}
