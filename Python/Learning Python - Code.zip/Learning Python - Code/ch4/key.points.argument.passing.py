x = 3
def func(y):
    print(y)

func(x)  # prints: 3
