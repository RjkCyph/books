import lib.funcdef


print(lib.funcdef.square(10))
print(lib.funcdef.cube(10))
