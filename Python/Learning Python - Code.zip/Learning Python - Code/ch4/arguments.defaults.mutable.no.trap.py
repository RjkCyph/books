def func(a=None):
    if a is None:
        a = []
    # do whatever you want with `a` ...
