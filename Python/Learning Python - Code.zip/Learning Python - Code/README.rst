==================================
Learning Python Book - Source Code
==================================

This project holds the Learning Python Book Source Code.


Setup
=====

Create a virtualenv, install all the requirements text files via pip like this:

    $ pip install -r requirements.txt

To update requirements you can use `pip-tools` to compile the `*.in`
sources in the `requirements` folder.


Python Version
==============

Python 3.4.6 (default, Feb 18 2017, 00:04:14)


### Last update

2017.02.26
