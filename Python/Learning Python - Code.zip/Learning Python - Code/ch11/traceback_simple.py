d = {'some': 'key'}
key = 'some-other'
print(d[key])
