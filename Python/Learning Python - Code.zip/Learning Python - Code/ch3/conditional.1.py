late = True
if late:
    print('I need to call my manager!')
